<?php
//$x = 10;
//$x = $x + 1;
//$x += 1;
//$x++;//постфиксная форма инкремента
//++$x;//префиксная форма инкремента


//постфиксная форма инкремента
//$a = 10;
//$b = $a++;
//echo "\$a=$a<br>\$b=$b";

//$a = 10;
//$b = ++$a;
//echo "\$a=$a<br>\$b=$b";

//$a = $a * 5;
//$a *= 5;

//$a = 10;
//$b = $a % 3;

//$today = date("w");//1
//
////$budniyDay = ($today != 6 || $today!=0);
//$budniyDay = !($today > 0 || $today < 6);
//
//$x = 1;
//$y = "1";
//
//echo $x == $y;//true
//echo $x === $y;//тождественное сравнение


$list = "<ul>";
$list .= "<li>Элемент №1</li><li>Элемент №2</li><li>Элемент №3</li>";
$list .= "</ul>";
echo $list;

//$x = 25.345;
////$y = (int)$x;
////echo (int)$x;
//
//define("MY_CONST",275);
//const TEST = 10;
////echo MY_CONST;
//
//echo TEST;
//
//echo "<hr>".round(25.34646,1);

//echo ([10,20,39]);















