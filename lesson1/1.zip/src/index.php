﻿<meta charset="utf-8">
<?php
    //echo "<h2>Привет! Сегодня ".date("d.m.Y")."</h2>";
?>
<hr>
<?php //"Сегодня ".date("d.m.Y")?>


<h2>Сегодня <?= date("d.m.Y")?> </h2>

<?php

$today = date("d.m.Y");

echo "Дата $today";
    
echo "Проект \"САОС\" - самый успешный проект компании";

?>

<h3>Заголок</h3>